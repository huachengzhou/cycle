---
title: "groovy 学习与使用 "
date: 2021-04-15
draft: false
weight: 20
---


> Groovy是一种面向对象的动态类型语言，跟Java一样运行在JVM上。
>
> （注：给Java静态世界带来动态能力的语言）



## 目录


* [groovy中对象的比较以及非空判断](groovy中对象的比较以及非空判断)

* [groovy使用场景](groovy使用场景)

* [groovy变量](groovy变量)

* [groovy变量和数据类型加强](groovy变量和数据类型加强)

* [groovy基本概念](groovy基本概念)

* [groovy学习](groovy学习)

* [groovy数据类型](groovy数据类型)

* [如何在groovy中获取以另一个变量命名的变量的值](如何在groovy中获取以另一个变量命名的变量的值)


## [回到上一级](../)

