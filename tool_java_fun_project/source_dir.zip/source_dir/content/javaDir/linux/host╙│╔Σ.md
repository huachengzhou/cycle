---
title: "host映射"
date: 2020-01-17T15:26:15Z
draft: false
weight: 1
---


sudo vi hosts

127.0.0.1	localhost
127.0.1.1	zhou-Lenovo-Z480

# The following lines are desirable for IPv6 capable hosts
::1     ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters

#pmcc dev
127.0.0.1 dev.pmcc.com

## [回到上一级](../)