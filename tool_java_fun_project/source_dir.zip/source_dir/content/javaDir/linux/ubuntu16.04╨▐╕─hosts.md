
---
title: "Ubuntu 16.04修改hosts"
date: 2020-01-17T15:26:15Z
draft: false
weight: 1
---

IntelliJ IDE运行Tomcat报错解决办法的相关资料,出现“Unable to ping server at localhost:1099”错误解决方法，需要的朋友可以参考下




sudo gedit /etc/hosts





## [回到上一级](../)


















