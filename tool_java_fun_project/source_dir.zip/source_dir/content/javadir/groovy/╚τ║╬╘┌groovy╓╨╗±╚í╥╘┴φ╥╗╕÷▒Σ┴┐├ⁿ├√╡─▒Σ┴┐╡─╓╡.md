
---
title: " groovy变量值获取 "
date: 2021-04-15
draft: false
weight: 5
---





# groovy变量值获取





`

https://www.codenong.com/34288451/

`



## [回到上一级](../)