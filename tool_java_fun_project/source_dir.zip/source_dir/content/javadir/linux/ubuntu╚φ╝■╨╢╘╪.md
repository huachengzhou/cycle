
---
title: "ubuntu软件卸载"
date: 2020-01-17T15:26:15Z
draft: false
weight: 1
---


ubuntu软件卸载

安装Synaptic

sudo apt-get install synaptic


## [回到上一级](../)