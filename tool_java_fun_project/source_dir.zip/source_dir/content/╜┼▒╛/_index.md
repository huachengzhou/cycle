---
title: "脚本"
date: 2017-10-17T15:26:15Z
draft: false
weight: 100
---





> dos,lua,sheel,python,js
  
+ dos 可以使用VisualBat编辑器编写以及调试

+ lua 可以运行在redis ,dos,Java,c++等里面另外还可以用来写触屏精灵 http://www.touchsprite.com/docs/5362 ==> https://www.zybuluo.com/miniknife/note/317045#%E5%BE%AA%E7%8E%AF%E8%AF%AD%E5%8F%A5

+ sheel脚本 运行在linux或者unix上相当于windows上的dos

+ python 胶水语言 可以直接在linux当成sheel使用,也是人工智能的一种使用工具

+ js 浏览器脚本