
---
title: "idea 解决working directory 设置到 target"
date: 2021-01-17T15:26:15Z
draft: false
---








+ idea 解决working directory 设置到 target
```
test ng D:\IdeaProjects\java-se-study

run config $MODULE_DIR$

```















