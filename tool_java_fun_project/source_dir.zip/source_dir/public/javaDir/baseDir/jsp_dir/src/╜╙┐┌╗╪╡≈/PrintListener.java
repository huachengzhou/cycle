package �ӿڻص�;

public interface PrintListener {
	public void print();
}
